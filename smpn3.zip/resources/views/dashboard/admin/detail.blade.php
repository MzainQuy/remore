@foreach ($prestasis as $item)
    {{ $item->jenis_kegiatan }}
@endforeach
