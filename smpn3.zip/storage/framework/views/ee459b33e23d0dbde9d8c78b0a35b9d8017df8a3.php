<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css"
        integrity="sha512-EZSUkJWTjzDlspOoPSpUFR0o0Xy7jdzW//6qhUkoZ9c4StFkVsp9fbbd0O06p9ELS3H486m4wmrCELjza4JEog=="
        crossorigin="anonymous" referrerpolicy="no-referrer">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <div id="sidebarMain">
        <!-- sidebar -->
        <div class="wrapperSidebar">
            <div class="brandLogo">
                <img src="<?php echo e(url('assets/img/smpn 3 cicurug 2.svg')); ?>" alt="">
            </div>
            <a href="#" class="profile">
                <div class="imagesProfile">
                    <img src="<?php echo e(url('assets/img/faces.jpeg')); ?>" alt="">
                </div>
                <div class="profileUser">
                    <h5 class="labelDay">Morning</h5>
                    <h5 class="nameUser"><?php echo e(auth()->user()->name); ?></h5>
                </div>
            </a>
            <div class="sidebar-menu-wrapper">
                <li class="listMenuName">
                    <p>Admin Menu</p>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="grid"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-menu">Dashboard</a>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="people"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('users.index')); ?>" class="sidebar-menu">Kelola User</a>
                </li>
                <li class="list-menu active">
                    <div class="icon">
                        <ion-icon name="home"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('beranda.index')); ?>" class="sidebar-menu">Kelola Beranda</a>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="newspaper"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('berita.index')); ?>" class="sidebar-menu">Kelola Berita</a>
                </li>
                <li class="list-menu">
                    <div class="icon">
                        <ion-icon name="accessibility"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('ekstrakurikuler.index')); ?>" class="sidebar-menu">Kelola ekstrakurikuler</a>
                </li>
                <li class="list-menu">
                    <div class="icon">
                        <ion-icon name="medal"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('prestasi.index')); ?>" class="sidebar-menu">Kelola Prestasi</a>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="school"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('tentang-kami.index')); ?>" class="sidebar-menu">Kelola Tentang Kami</a>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="call"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('contact.index')); ?>" class="sidebar-menu">Kelola Kontak</a>
                </li>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .dropify-wrapper .dropify-message p {
            font-size: 14px;
        }

    </style>

    <h2 class="pageNameContent">Dashboard</h2>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">SMPN 3 CICURUG</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>

    <ul class="nav nav-pills mb-3 tabsMenu" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="new-request-tab" data-bs-toggle="pill" data-bs-target="#newRequestTab"
                type="button" role="tab" aria-controls="newRequestTab" aria-selected="true">Banner</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="list-request-tab" data-bs-toggle="pill" data-bs-target="#listRequestTab"
                type="button" role="tab" aria-controls="listRequestTab" aria-selected="false">Kata Sambutan</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="kegiatan-tab" data-bs-toggle="pill" data-bs-target="#kegiatanTab"
                type="button" role="tab" aria-controls="kegiatanTab" aria-selected="false">Kegiatan</button>
        </li>
    </ul>

    <div class="tab-content" id="pills-tabContent">

        <div class="tab-pane fade show active" id="newRequestTab" role="tabpanel" aria-labelledby="new-request-tab">
            <div class="wrapperTable table-responsive">
                <table id="bannerTable" class="tables" style="width:100%">
                    <thead>
                        <tr>
                            <th style="width: 15%">#</th>
                            <th style="width: 70%">Banner</th>
                            <th style="width: 15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = DB::table('banners')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><img style="max-height: 250px;max-width:250px;min-width:250px;min-height:250px;"
                                        src="<?php echo e(url('thumbBanner/' . $item->image)); ?>" alt=""></td>
                                <td>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary me-3" data-bs-toggle="modal"
                                        data-bs-target="#editBanner" data-id="<?php echo e($item->id); ?>"
                                        data-image="<?php echo e($item->image); ?>">
                                        Edit
                                    </button>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="tab-pane fade" id="listRequestTab" role="tabpanel" aria-labelledby="list-request-tab">

            <div class="wrapperTable table-responsive">
                <table id="sambutanTable" class="tables" style="width:100%">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Image</th>
                            <th>Content</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = DB::table('sambutan')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><img style="max-height: 250px;max-width:250px;min-width:250px;min-height:250px;"
                                        src="<?php echo e(url('thumbSambutan/' . $item->image)); ?>" alt=""></td>

                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->content); ?></td>
                                <td>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#editSambutan" data-id="<?php echo e($item->id); ?>"
                                        data-title="<?php echo e($item->title); ?>" data-content="<?php echo e($item->content); ?>"
                                        data-image="<?php echo e($item->image); ?>">
                                        Edit
                                    </button>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>

        <div class="tab-pane fade show" id="kegiatanTab" role="tabpanel" aria-labelledby="kegiatan-tab">

            <div class="d-flex justify-content-end">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahKegiatan">
                    Tambah
                </button>

                <!-- Modal -->
                <div class="modal fade" id="tambahKegiatan" tabindex="-1" aria-labelledby="tambahKegiatanLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahKegiatanLabel">Modal title</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('beranda.activity.create')); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <input type="file" name="image" class="dropify" data-max-width="2000"
                                        data-max-width="2000" />

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save changes</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="wrapperTable table-responsive">
                <table id="kegiatanTable" class="tables" style="width:100%">
                    <thead>
                        <tr>
                            <th style="width: 15%">#</th>
                            <th style="width: 70%">foto</th>
                            <th style="width: 15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = DB::table('kegiatans')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><img src="<?php echo e(url('thumbKegiatan/' . $item->image)); ?>" alt=""></td>
                                <td>

                                    <a href="<?php echo e(route('beranda.activity.delete', ['id' => $item->id])); ?>"
                                        class="btn btn-danger">Hapus</a>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#editKegiatan" data-id="<?php echo e($item->id); ?>"
                                        data-image="<?php echo e($item->image); ?>">
                                        Edit
                                    </button>

                                    <!-- Modal -->

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editBanner" tabindex="-1" aria-labelledby="editBannerLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" id="modal-editBanner">
                <div class="modal-header">
                    <h5 class="modal-title" id="editBannerLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editSambutan" tabindex="-1" aria-labelledby="editSambutanLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" id="modal-editSambutan">
                <div class="modal-header">
                    <h5 class="modal-title" id="editSambutanLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editKegiatan" tabindex="-1" aria-labelledby="editKegiatanLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" id="modal-editKegiatan">
                <div class="modal-header">
                    <h5 class="modal-title" id="editKegiatanLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"
        integrity="sha512-8QFTrG0oeOiyWo/VM9Y8kgxdlCryqhIxVeRpWSezdRRAvarxVtwLnGroJgnVW9/XBRduxO/z1GblzPrMQoeuew=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $('.dropify').dropify();
    </script>
    <script>
        $(document).ready(function() {
            $('#bannerTable').DataTable({
                "info": false,
                "bSort": false,
            });
        });

        $(document).ready(function() {
            $('#sambutanTable').DataTable({
                "info": false,
                "bSort": false,
            });
        });

        $(document).ready(function() {
            $('#kegiatanTable').DataTable({
                "info": false,
                "bSort": false,
            });
        });
    </script>



    <script>
        $('#editBanner').on('shown.bs.modal', function(e) {
            var html = `
<div id="modal-content" class="modal-content">
            <form action="/management/beranda/banner/edit/${$(e.relatedTarget).data('id')}" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>


                <p style="color:red; font-size:12px; margin-bottom:10px; margin-top:10px">Ukuran Gambar Minimal width:1440px & height:670</p>

                <input type="file" name="image" class="dropify"
                data-max-width="1220" data-max-width="650"
                data-default-file="/thumbBanner/${$(e.relatedTarget).data('image')}" />


                <br>
                <br>
                <center> <button class="btn btn-success" type="submit">Submit</button>
                </center>

            </form>
        </div>
`;

            $('#modal-editBanner').html(html);
            $('.dropify').dropify();

        });

        $('#editSambutan').on('shown.bs.modal', function(e) {
            var html = `
<div id="modal-content" class="modal-content">
            <form action="/management/beranda/about/edit/${$(e.relatedTarget).data('id')}" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                        <label for="title" class="form-label">title</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="isi title " value="${$(e.relatedTarget).data('title')}">
                    </div>

                    <div class="mb-3">
                        <label for="content" class="form-label">content</label>
                        <input type="text" class="form-control" id="content" name="content" placeholder="isi content " value="${$(e.relatedTarget).data('content')}">
                    </div>

                <input type="file" name="image" class="dropify" data-max-width="375" data-max-width="215"
                data-default-file="/thumbSambutan/${$(e.relatedTarget).data('image')}" />


                <br>
                <br>
                <center> <button class="btn btn-success" type="submit">Submit</button>
                </center>

            </form>
        </div>
`;

            $('#modal-editSambutan').html(html);
            $('.dropify').dropify();

        });

        $('#editKegiatan').on('shown.bs.modal', function(e) {
            var html = `
<div id="modal-content" class="modal-content">
            <form action="/management/beranda/activity/edit/${$(e.relatedTarget).data('id')}" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>



                <input type="file" name="image" class="dropify" data-max-width="2000" data-max-width="2000"
                data-default-file="/thumbKegiatan/${$(e.relatedTarget).data('image')}" />


                <br>
                <br>
                <center> <button class="btn btn-success" type="submit">Submit</button>
                </center>

            </form>
        </div>
`;

            $('#modal-editKegiatan').html(html);
            $('.dropify').dropify();

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\Laravel\Smpn-3-cicurug\resources\views/dashboard/admin/kelolaBeranda.blade.php ENDPATH**/ ?>