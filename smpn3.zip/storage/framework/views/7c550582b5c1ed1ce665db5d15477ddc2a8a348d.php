<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<div id="sidebarMain">
    <!-- sidebar -->
    <div class="wrapperSidebar">
        <div class="brandLogo">
            <img src="<?php echo e(url('assets/img/smpn 3 cicurug 2.svg')); ?>" alt="">
        </div>
        <a href="#" class="profile">
            <div class="imagesProfile">
                <img src="<?php echo e(url('assets/img/faces.jpeg')); ?>" alt="">
            </div>
            <div class="profileUser">
                <h5 class="labelDay">Morning</h5>
                <h5 class="nameUser">Louis Milla</h5>
            </div>
        </a>
        <div class="sidebar-menu-wrapper">
            <li class="listMenuName">
                <p>Admin Menu</p>
            </li>
            <li class="list-menu ">
                <div class="icon">
                    <ion-icon name="grid"></ion-icon>
                </div>
                <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-menu">Dashboard</a>
            </li>
            <li class="list-menu ">
                <div class="icon">
                    <ion-icon name="people"></ion-icon>
                </div>
                <a href="<?php echo e(route('users.index')); ?>" class="sidebar-menu">Kelola User</a>
            </li>
            <li class="list-menu ">
                <div class="icon">
                    <ion-icon name="home"></ion-icon>
                </div>
                <a href="<?php echo e(route('beranda.index')); ?>" class="sidebar-menu">Kelola Beranda</a>
            </li>
            <li class="list-menu ">
                <div class="icon">
                    <ion-icon name="newspaper"></ion-icon>
                </div>
                <a href="<?php echo e(route('berita.index')); ?>" class="sidebar-menu">Kelola Berita</a>
            </li>
            <li class="list-menu ">
                <div class="icon">
                    <ion-icon name="accessibility"></ion-icon>
                </div>
                <a href="<?php echo e(route('ekstrakurikuler.index')); ?>" class="sidebar-menu">Kelola Ekstrakurikuler</a>
            </li>
            <li class="list-menu ">
                <div class="icon">
                    <ion-icon name="medal"></ion-icon>
                </div>
                <a href="<?php echo e(route('prestasi.index')); ?>" class="sidebar-menu">Kelola Prestasi</a>
            </li>
            <li class="list-menu active">
                <div class="icon">
                    <ion-icon name="school"></ion-icon>
                </div>
                <a href="<?php echo e(route('tentang-kami.index')); ?>" class="sidebar-menu">Kelola Tentang Kami</a>
            </li>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h2 class="pageNameContent">Kelola Tentang Kami</h2>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">SMPN 3 CICURUG</a></li>
        <li class="breadcrumb-item active">Tentang Kami</li>
    </ol>

    <ul class="nav nav-pills mb-3 tabsMenu" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="new-request-tab" data-bs-toggle="pill" data-bs-target="#newRequestTab"
                type="button" role="tab" aria-controls="newRequestTab" aria-selected="true">Visi & Misi</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="list-request-tab" data-bs-toggle="pill" data-bs-target="#listRequestTab"
                type="button" role="tab" aria-controls="listRequestTab" aria-selected="false">Tenaga Pengajar</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="kegiatan-tab" data-bs-toggle="pill" data-bs-target="#kegiatanTab"
                type="button" role="tab" aria-controls="kegiatanTab" aria-selected="false">Sejarah</button>
        </li>
    </ul>

    <div class="tab-content" id="pills-tabContent">

        <div class="tab-pane fade show active" id="newRequestTab" role="tabpanel" aria-labelledby="new-request-tab">
            <div class="wrapperTable table-responsive">
                <table id="VmTable" class="tables" style="width:100%">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Visi</th>
                            <th>Misi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = DB::table('profils')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item->visi); ?></td>
                            <td><?php echo e($item->misi); ?></td>
                            <td>
                                <button type="button" class="btn btn-primary show-edit-modal" data-bs-toggle="modal"
                                    data-bs-target="#editVisimisi" data-id="<?php echo e($item->id); ?>"
                                    data-visi="<?php echo e($item->visi); ?>" data-misi="<?php echo e($item->misi); ?>">
                                    Edit
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>

        <div class="tab-pane fade" id="listRequestTab" role="tabpanel" aria-labelledby="list-request-tab">

            <div class="d-flex justify-content-end">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahGuru">
                    Tambah
                </button>

                <!-- Modal -->
                <div class="modal fade" id="tambahGuru" tabindex="-1" aria-labelledby="tambahGuruLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahGuruLabel">Modal title</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('tentang-kami.guru.create')); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="jabatan" class="form-label">Jabatan</label>
                                        <input type="text" class="form-control" id="jabatan" aria-describedby="jabatan" name="jabatan">
                                    </div>
                                    <div class="mb-3">
                                        <label for="nama" class="form-label">Nama Guru</label>
                                        <input type="text" class="form-control" id="nama" aria-describedby="nama" name="nama">
                                    </div>
                                    <div class="mb-3">
                                        <label for="gelar" class="form-label">Gelar Guru</label>
                                        <input type="text" class="form-control" id="gelar" aria-describedby="gelar" name="gelar">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save changes</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>

            </div>

            <div class="wrapperTable table-responsive">
                <table id="guruTable" class="tables" style="width:100%">
                    <thead>
                        <tr>
                            <th style="width: 5%">#</th>
                            <th style="width: 30%">Jabatan</th>
                            <th style="width: 30%">Nama Guru</th>
                            <th style="width: 30%">Gelar</th>
                            <th style="width: 5%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = DB::table('teachers')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item->jabatan); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($item->gelar); ?></td>
                            <td>
                                <button type="button" class="btn btn-primary show-edit-modal-guru" data-bs-toggle="modal"
                                data-bs-target="#editGuru" data-id="<?php echo e($item->id); ?>"
                                data-jabatan="<?php echo e($item->jabatan); ?>" data-nama="<?php echo e($item->nama); ?>"
                                data-gelar="<?php echo e($item->gelar); ?>">
                                Edit
                                </button>
                                <a class="btn btn-danger"
                                href="<?php echo e(route('tentang-kami.guru.delete', ['id' => $item->id])); ?>">Hapus<a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>

        <div class="tab-pane fade show" id="kegiatanTab" role="tabpanel" aria-labelledby="kegiatan-tab">

            <div class="wrapperTable table-responsive">
                <table id="kegiatanTable" class="tables" style="width:100%">
                    <thead>
                        <tr>
                            <th style="width: 10%">#</th>
                            <th style="width: 80%">Sejarah</th>
                            <th style="width: 10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = DB::table('profils')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item->sejarah); ?></td>
                            <td>
                                <button type="button" class="btn btn-primary show-edit-modal-sejarah" data-bs-toggle="modal"
                                data-bs-target="#editSejarah" data-id="<?php echo e($item->id); ?>" data-sejarah="<?php echo e($item->sejarah); ?>">
                                Edit
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editVisimisi" tabindex="-1" aria-labelledby="editVisimisiLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" id="modal-editVisimisi">
                <div class="modal-header">
                    <h5 class="modal-title" id="editVisimisiLabel">Edit Visi & Misi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <form action="<?php echo url('management/tentang-kami/visimisi/edit'); ?>" method="post">
                        <input type="hidden" id="visi-misi-id" name="id">
                        <?php echo csrf_field(); ?>
                        <label for="visi">Visi</label>
                        <div class="form-floating mb-3">
                            <textarea class="form-control" placeholder="Visi" id="visi" style="height: 100px" name="visi"></textarea>
                        </div>
                        <label for="misi">Misi</label>
                        <div class="form-floating mb-3">
                            <textarea class="form-control" placeholder="Misi" id="misi" style="height: 100px" name="misi"></textarea>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editSejarah" tabindex="-1" aria-labelledby="editSejarahLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" id="modal-editSejarah">
                <div class="modal-header">
                    <h5 class="modal-title" id="editSejarahLabel">Edit Sejarah</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <form action="<?php echo url('management/tentang-kami/sejarah/edit'); ?>" method="post">
                        <input type="hidden" id="sejarah-id" name="id">
                        <?php echo csrf_field(); ?>
                        <label for="sejarah">Sejarah</label>
                        <div class="form-floating mb-3">
                            <textarea class="form-control" placeholder="sejarah" id="sejarah" style="height: 100px" name="sejarah"></textarea>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editGuru" tabindex="-1" aria-labelledby="editGuruLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" id="modal-editGuru">
                <div class="modal-header">
                    <h5 class="modal-title" id="editGuruLabel">Edit Jabatan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <form action="<?php echo url('management/tentang-kami/guru/edit'); ?>" method="post">
                        <input type="hidden" id="guru-id" name="id">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="jabatan" class="form-label">Jabatan</label>
                            <input type="text" class="form-control" id="jabatan" aria-describedby="jabatan" name="jabatan" value="">
                        </div>
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Guru</label>
                            <input type="text" class="form-control" id="nama" aria-describedby="nama" name="nama" value="">
                        </div>
                        <div class="mb-3">
                            <label for="gelar" class="form-label">Gelar Guru</label>
                            <input type="text" class="form-control" id="gelar" aria-describedby="gelar" name="gelar" value="">
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"
        integrity="sha512-8QFTrG0oeOiyWo/VM9Y8kgxdlCryqhIxVeRpWSezdRRAvarxVtwLnGroJgnVW9/XBRduxO/z1GblzPrMQoeuew=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $('.dropify').dropify();
    </script>
    <script>
        $(document).ready(function() {
            $('#VmTable').DataTable({
                "info": false,
                "bSort": false,
            });
        });

        $(document).ready(function() {
            $('#guruTable').DataTable({
                "info": false,
                "bSort": false,
            });
        });

        $(document).ready(function() {
            $('#kegiatanTable').DataTable({
                "info": false,
                "bSort": false,
            });
        });
    </script>

    <script>
        $('.show-edit-modal').each(function(){
            $(this).click(function(){
                $('#visi').val($(this).data('visi'));
                $('#misi').val($(this).data('misi'));
                $('#visi-misi-id').val($(this).data('id'));
            });
        });

        $('.show-edit-modal-sejarah').each(function(){
            $(this).click(function(){
                $('#sejarah').val($(this).data('sejarah'));
                $('#sejarah-id').val($(this).data('id'));
            });
        });

        $('.show-edit-modal-guru').each(function(){
            $(this).click(function(){
                $('#jabatan').val($(this).data('jabatan'));
                $('#nama').val($(this).data('nama'));
                $('#gelar').val($(this).data('gelar'));
                $('#guru-id').val($(this).data('id'));
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\Laravel\Smpn-3-cicurug\resources\views/dashboard/admin/kelolaTentangKami.blade.php ENDPATH**/ ?>