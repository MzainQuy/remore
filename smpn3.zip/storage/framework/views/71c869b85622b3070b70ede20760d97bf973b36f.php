<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css"
        integrity="sha512-EZSUkJWTjzDlspOoPSpUFR0o0Xy7jdzW//6qhUkoZ9c4StFkVsp9fbbd0O06p9ELS3H486m4wmrCELjza4JEog=="
        crossorigin="anonymous" referrerpolicy="no-referrer">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <div id="sidebarMain">
        <!-- sidebar -->
        <div class="wrapperSidebar">
            <div class="brandLogo">
                <img src="<?php echo e(url('assets/img/smpn 3 cicurug 2.svg')); ?>" alt="">
            </div>
            <a href="#" class="profile">
                <div class="imagesProfile">
                    <img src="<?php echo e(url('assets/img/faces.jpeg')); ?>" alt="">
                </div>
                <div class="profileUser">
                    <h5 class="labelDay">Morning</h5>
                    <h5 class="nameUser">Louis Milla</h5>
                </div>
            </a>
            <div class="sidebar-menu-wrapper">
                <li class="listMenuName">
                    <p>Admin Menu</p>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="grid"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-menu">Dashboard</a>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="people"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('users.index')); ?>" class="sidebar-menu">Kelola User</a>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="home"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('beranda.index')); ?>" class="sidebar-menu">Kelola Beranda</a>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="newspaper"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('berita.index')); ?>" class="sidebar-menu">Kelola Berita</a>
                </li>
                <li class="list-menu active">
                    <div class="icon">
                        <ion-icon name="accessibility"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('ekstrakurikuler.index')); ?>" class="sidebar-menu">Kelola Ekstrakurikuler</a>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="medal"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('prestasi.index')); ?>" class="sidebar-menu">Kelola Prestasi</a>
                </li>
                <li class="list-menu ">
                    <div class="icon">
                        <ion-icon name="school"></ion-icon>
                    </div>
                    <a href="<?php echo e(route('tentang-kami.index')); ?>" class="sidebar-menu">Kelola Tentang Kami</a>
                </li>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="pageNameContent">Kelola Ekstrakurikuler</h2>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">SMPN 3 CICURUG</a></li>
        <li class="breadcrumb-item active">Kelola Ekstrakurikuler</li>
    </ol>

    <div class="d-flex justify-content-end">
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambaheskul">
            Tambah
        </button>

    </div>

    <div class="wrapperTable table-responsive">
        <table id="sambutanTable" class="tables" style="width:100%">
            <thead>
                <tr>
                    <th style="width: 5%">#</th>
                    <th style="width: 30%">Gambar</th>
                    <th style="width: 30%">Judul</th>
                    <th style="width: 30%">Kata - Kata</th>
                    <th style="width: 5%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = DB::table('ekskuls')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><img src="<?php echo e(url('thumbEskul/' . $item->image)); ?>" alt=""></td>
                        <td><?php echo e($item->title); ?></td>
                        <td>
                            <a class="btn btn-danger"
                                href="<?php echo e(route('ekstrakurikuler.delete', ['id' => $item->id])); ?>">Hapus</a>

                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#editeskul" data-id="<?php echo e($item->id); ?>"
                                data-title="<?php echo e($item->title); ?>"
                                data-image="<?php echo e($item->image); ?>">
                                Edit
                            </button>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


        <!-- Modal Create -->
        <div class="modal fade" id="tambaheskul" tabindex="-1" aria-labelledby="tambaheskulLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="tambaheskulLabel">Tambah Ekskul</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form action="<?php echo e(route('ekstrakurikuler.create')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="title" class="form-label">title</label>
                                <input type="text" class="form-control" id="title" name="title" placeholder="isi title "
                                    required>
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Body</label>
                                <textarea class="form-control" name="body" placeholder="Masukan Konten"
                                    id="editor"></textarea>
                            </div>

                            <input type="file" name="image" class="dropify" data-max-width="320" data-max-width="180"
                                required />



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Edit -->
        <div class="modal fade" id="editeskul" tabindex="-1" aria-labelledby="editeskulLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content" id="editData">

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"
        integrity="sha512-8QFTrG0oeOiyWo/VM9Y8kgxdlCryqhIxVeRpWSezdRRAvarxVtwLnGroJgnVW9/XBRduxO/z1GblzPrMQoeuew=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $('.dropify').dropify();
    </script>


    <script>
        $('#editeskul').on('shown.bs.modal', function(e) {
            var html = `<div class="modal-header">
              <h5 class="modal-title" id="editeskulLabel">Modal title</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <form action="/management/ekstrakurikuler/edit/${$(e.relatedTarget).data('id')}" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="title" class="form-label">title</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="isi title " value="${$(e.relatedTarget).data('title')}">
                    </div>

                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Body</label>
                        <textarea class="form-control" name="body" placeholder="Masukan Konten" id="editor">${$(e.relatedTarget).data('body')}</textarea>
                    </div>


                    <input type="file" name="image" class="dropify" data-max-width="320" data-max-width="190"
                    data-default-file="/thumbEskul/${$(e.relatedTarget).data('image')}" />

                    <div class="d-flex mt-3 justify-content-end">
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>

                </div>
            </form>`;


            $('#editData').html(html);
            $('.dropify').dropify();
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#bannerTable').DataTable({
                "info": false,
                "bSort": false,
            });
        });

        $(document).ready(function() {
            $('#sambutanTable').DataTable({
                "info": false,
                "bSort": false,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\Laravel\Smpn-3-cicurug\resources\views/dashboard/admin/kelolaEskul.blade.php ENDPATH**/ ?>