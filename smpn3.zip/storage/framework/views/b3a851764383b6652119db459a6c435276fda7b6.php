

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | SMPN 3 CICURUG</title>

    <!--Bootstrap Assets-->
    <link rel="stylesheet" href="/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/vendor/bootstrap/icons-1.7.2/font/bootstrap-icons.css">

    <!--Auth Css-->
    <link rel="stylesheet" href="/css/auth.css">
</head>

<body>

    <div id="auth">
        <div class="imagesAuth">
            <img src="/img/auth.png" alt="">
        </div>
        <div class="sectionFormAuth">
            <div class="headAuth">
                <h1>Lupa kata sandi Anda?</h1>
                <p>Masukkan alamat email yang terdaftar pada aplikasi ini.</p>
            </div>
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?> <a href="https://mailtrap.io/inboxes/1636674/messages">Silahkan klik!</a>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('password.email')); ?>" class="formAuth">
                <?php echo csrf_field(); ?>
                <div class="mb-3 inputForm passwordForm">
                    <div class="icon">
                        <label for="newPassword">
                            <img src="/img/iconLock.svg" alt="">
                        </label>
                    </div>
                    <div class="wrapperToggle">
                        <i class="bi bi-eye-fill" id="togglePassword"></i>
                    </div>
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> email"
                        name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus
                        placeholder="Email">

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="actionUser d-flex justify-content-center flex-column align-items-center">
                    <button type="submit" class="btn btnPrimary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal">Submit</button>
                    <p class="text">Batal mengubah password ? <a href="<?php echo e(route('login')); ?>">masuk!</a>
                    </p>
                </div>
            </form>
        </div>
    </div>




    <!--Vendor-->
    <!--Bootstrap JS-->
    <script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!--Script Auth-->
    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function(e) {
            // toggle the type attribute
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);

            this.classList.toggle('bi-eye-slash-fill');
        });
    </script>
</body>

</html>
<?php /**PATH D:\Documents\Laravel\Smpn-3-cicurug\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>